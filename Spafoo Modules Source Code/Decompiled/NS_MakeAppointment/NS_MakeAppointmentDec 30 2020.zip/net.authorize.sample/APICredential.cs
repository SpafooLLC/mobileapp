namespace net.authorize.sample
{
	internal static class APICredential
	{
		public static string APILoginID
		{
			get
			{
				return "2G2ThG44se";
			}
		}

		public static string TransactionKey
		{
			get
			{
				return "39fc4U3T4Y3ks2hM";
			}
		}
	}
}
