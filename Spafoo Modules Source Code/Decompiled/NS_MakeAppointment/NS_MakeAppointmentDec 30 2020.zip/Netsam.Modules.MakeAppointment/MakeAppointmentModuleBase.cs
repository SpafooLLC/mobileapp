using DotNetNuke.Entities.Modules;
namespace Netsam.Modules.MakeAppointment
{
	public class MakeAppointmentModuleBase : PortalModuleBase
    {
		public MakeAppointmentModuleBase()
			
		{
		}
	}
}
