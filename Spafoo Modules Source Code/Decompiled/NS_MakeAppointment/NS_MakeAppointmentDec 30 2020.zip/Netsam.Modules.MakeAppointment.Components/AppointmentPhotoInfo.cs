namespace Netsam.Modules.MakeAppointment.Components
{
	public class AppointmentPhotoInfo
	{
		public int ID
		{
			get;
			set;
		}

		public int UserID
		{
			get;
			set;
		}

		public int AppointmentID
		{
			get;
			set;
		}

		public string FilePath
		{
			get;
			set;
		}
	}
}
