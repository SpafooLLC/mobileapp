namespace Netsam.Modules.MakeAppointment.Components
{
	public class NotificationType
	{
		public int NotificiationTypeID
		{
			get;
			set;
		}

		public string TypeName
		{
			get;
			set;
		}

		public string DisplayText
		{
			get;
			set;
		}
	}
}
