namespace Netsam.Modules.MakeAppointment.Components
{
	public class UserPaymentProfile
	{
		public int UserID
		{
			get;
			set;
		}

		public string CustomerProfileID
		{
			get;
			set;
		}
	}
}
