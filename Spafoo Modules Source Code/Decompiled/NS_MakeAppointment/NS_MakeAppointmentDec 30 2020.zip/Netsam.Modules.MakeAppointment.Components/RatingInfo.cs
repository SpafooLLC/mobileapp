namespace Netsam.Modules.MakeAppointment.Components
{
	public class RatingInfo
	{
		public string RatingName
		{
			get;
			set;
		}

		public int RatingTypeID
		{
			get;
			set;
		}

		public int RatingFilter
		{
			get;
			set;
		}
	}
}
