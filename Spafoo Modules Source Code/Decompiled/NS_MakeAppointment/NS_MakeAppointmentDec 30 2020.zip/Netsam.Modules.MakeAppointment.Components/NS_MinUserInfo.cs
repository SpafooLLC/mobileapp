namespace Netsam.Modules.MakeAppointment.Components
{
	public class NS_MinUserInfo
	{
		public int UserID
		{
			get;
			set;
		}

		public string FirstName
		{
			get;
			set;
		}

		public string LastName
		{
			get;
			set;
		}

		public string PhoneNumber
		{
			get;
			set;
		}
	}
}
